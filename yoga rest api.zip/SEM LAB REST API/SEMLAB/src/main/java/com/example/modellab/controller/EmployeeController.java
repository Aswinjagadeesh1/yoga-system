package com.example.modellab.controller;

import com.example.modellab.entity.Employee;
import com.example.modellab.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    
    @PostMapping
    public Employee addEmployee(@RequestBody Employee employee) {
        return employeeService.save(employee);
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAll();
    }

    
    @GetMapping("/{id}")
    public Optional<Employee> getEmployeeById(@PathVariable Long id) {
        return employeeService.getById(id);
    }

  
    @GetMapping("/salary/{minSalary}")
    public List<Employee> getByMinSalary(@PathVariable double minSalary) {
        return employeeService.getByMinSalary(minSalary);
    }

   
    @GetMapping("/name/{name}")
    public List<Employee> getByName(@PathVariable String name) {
        return employeeService.getByName(name);
    }
}
