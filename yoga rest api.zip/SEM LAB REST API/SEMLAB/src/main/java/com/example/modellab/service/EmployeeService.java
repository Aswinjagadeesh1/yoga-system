package com.example.modellab.service;

import com.example.modellab.entity.Employee;
import com.example.modellab.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

   
    public Employee save(Employee employee) {
        return employeeRepository.save(employee);
    }

   
    public List<Employee> getAll() {
        return employeeRepository.findAll();
    }

  
    public Optional<Employee> getById(Long id) {
        return employeeRepository.findById(id);
    }

  
    public List<Employee> getByMinSalary(double minSalary) {
        return employeeRepository.findBySalaryGreaterThan(minSalary);
    }

    public List<Employee> getByName(String name) {
        return employeeRepository.findByFirstNameLike(name);
    }
}
