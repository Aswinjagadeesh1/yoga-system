package com.example.modellab.repository;

import com.example.modellab.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Custom JPQL Query
    @Query("SELECT e FROM Employee e WHERE e.salary > :minSalary")
    List<Employee> findBySalaryGreaterThan(double minSalary);

    // Native SQL Query
    @Query(value = "SELECT * FROM employees WHERE first_name LIKE %:name%", nativeQuery = true)
    List<Employee> findByFirstNameLike(String name);
}
