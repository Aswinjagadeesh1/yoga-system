package com.example.modellab.entity;

import jakarta.persistence.*; 

@Entity
@Table(name = "employees")

public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;

    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;

    @Column(name = "salary", columnDefinition = "double default 50000")  
    private double salary;

    public Employee(Long id, String firstName, String lastName, double salary, String temporaryNote) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = salary;
        this.temporaryNote = temporaryNote;
    }
public Employee(){
    
}
    @Transient   
    private String temporaryNote;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getTemporaryNote() {
        return temporaryNote;
    }

    public void setTemporaryNote(String temporaryNote) {
        this.temporaryNote = temporaryNote;
    }

}
