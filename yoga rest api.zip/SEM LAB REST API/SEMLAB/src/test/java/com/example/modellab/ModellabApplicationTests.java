package com.example.modellab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModellabApplicationTests {

	@Test
	void contextLoads() {
	}

}
